function siz = imsize(im)

siz = size(im(:,:,1));